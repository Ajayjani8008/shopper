# shoppers_product_management_plugin
plugin that manage product with pagination and ajax functionalities
