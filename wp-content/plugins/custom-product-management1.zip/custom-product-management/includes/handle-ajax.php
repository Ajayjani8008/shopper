<?php

if (!defined('ABSPATH')) exit;

// Handle save (add/update) product
function cpm_ajax_save_product()
{
    check_ajax_referer('cpm_product_nonce', 'nonce');

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    $product_data = [
        'post_title' => sanitize_text_field($_POST['product_name']),
        'post_content' => wp_kses_post($_POST['product_description']),
        'post_status' => 'publish',
        'post_type' => 'product',
    ];

    if ($product_id) {
        $product_data['ID'] = $product_id; // Update existing product
    }

    $product_id = wp_insert_post($product_data);

    if (!is_wp_error($product_id)) {
        $product = wc_get_product($product_id);

        // Set product price
        $product->set_regular_price(floatval($_POST['product_price']));

        // Set product category
        if (!empty($_POST['product_category'])) {
            wp_set_object_terms($product_id, intval($_POST['product_category']), 'product_cat');
        }

        // Set stock status
        $product->set_stock_status(sanitize_text_field($_POST['stock_status']));

        // Handle product image upload
        if (!empty($_FILES['product_image']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');

            $image_id = media_handle_upload('product_image', $product_id);

            if (!is_wp_error($image_id)) {
                set_post_thumbnail($product_id, $image_id);
            }
        }

        $product->save(); // Save product updates

        // Return success response
        ob_start();
        cpm_display_product_list(); // Use your separate function to render updated product list
        $product_list_html = ob_get_clean();

        wp_send_json_success([
            'message' => 'Product saved successfully.',
            'product_list' => $product_list_html,
        ]);
    } else {
        wp_send_json_error(['message' => 'Failed to save product.']);
    }
}
add_action('wp_ajax_cpm_save_product', 'cpm_ajax_save_product');

// Handle delete product
function cpm_ajax_delete_product()
{
    check_ajax_referer('cpm_product_nonce', 'nonce');

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    if ($product_id && wp_delete_post($product_id, true)) {
        // Refresh product list after deletion
        ob_start();
        cpm_display_product_list();
        $product_list_html = ob_get_clean();

        wp_send_json_success([
            'message' => 'Product deleted successfully.',
            'product_list' => $product_list_html,
        ]);
    } else {
        wp_send_json_error(['message' => 'Failed to delete product.']);
    }
}
add_action('wp_ajax_cpm_delete_product', 'cpm_ajax_delete_product');

// Handle fetch product details for editing
function cpm_ajax_fetch_product()
{
    check_ajax_referer('cpm_product_nonce', 'nonce');

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    if (!$product_id) {
        wp_send_json_error(['message' => 'Invalid product ID.']);
    }

    $product = wc_get_product($product_id);

    if ($product) {
        $response = [
            'id' => $product->get_id(),
            'name' => $product->get_name(),
            'price' => $product->get_regular_price(),
            'description' => $product->get_description(),
            'stock_status' => $product->get_stock_status(),
            'category' => wp_get_post_terms($product_id, 'product_cat', ['fields' => 'ids']),
            'image' => has_post_thumbnail($product_id) ? get_the_post_thumbnail_url($product_id, 'medium') : '',
        ];
        wp_send_json_success(['product' => $response]);
    } else {
        wp_send_json_error(['message' => 'Product not found.']);
    }
}
add_action('wp_ajax_cpm_fetch_product', 'cpm_ajax_fetch_product');

// Handle refresh product list
function cpm_ajax_refresh_product_list()
{
    check_ajax_referer('cpm_product_nonce', 'nonce');

    ob_start();
    cpm_display_product_list(); // Use the separate function to render product list
    $html = ob_get_clean();

    wp_send_json_success(['html' => $html]);
}
add_action('wp_ajax_cpm_refresh_product_list', 'cpm_ajax_refresh_product_list');
